CREATE DATABASE  IF NOT EXISTS `atosbd` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `atosbd`;
-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: atosbd
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `academiclevel`
--

DROP TABLE IF EXISTS `academiclevel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `academiclevel` (
  `academicLevelID` int NOT NULL,
  `academicLevel` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`academicLevelID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `academiclevel`
--

LOCK TABLES `academiclevel` WRITE;
/*!40000 ALTER TABLE `academiclevel` DISABLE KEYS */;
INSERT INTO `academiclevel` VALUES (1,'Elementary School'),(2,'Middle School'),(3,'High School'),(4,'University or College');
/*!40000 ALTER TABLE `academiclevel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `administrador`
--

DROP TABLE IF EXISTS `administrador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `administrador` (
  `adminID` int NOT NULL AUTO_INCREMENT,
  `adminName` varchar(45) DEFAULT NULL,
  `adminLastName` varchar(60) DEFAULT NULL,
  `adminPassword` varchar(45) DEFAULT NULL,
  `adminEmail` varchar(90) DEFAULT NULL,
  PRIMARY KEY (`adminID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administrador`
--

LOCK TABLES `administrador` WRITE;
/*!40000 ALTER TABLE `administrador` DISABLE KEYS */;
INSERT INTO `administrador` VALUES (1,'Axel','Hdz','contraseña','axel@atos.com');
/*!40000 ALTER TABLE `administrador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `applicant`
--

DROP TABLE IF EXISTS `applicant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applicant` (
  `applicantID` int NOT NULL AUTO_INCREMENT,
  `last_names` varchar(45) DEFAULT NULL,
  `dateOfBirth` date DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `photo` varchar(500) DEFAULT NULL,
  `first_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`applicantID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicant`
--

LOCK TABLES `applicant` WRITE;
/*!40000 ALTER TABLE `applicant` DISABLE KEYS */;
/*!40000 ALTER TABLE `applicant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `applicant_civilstatus`
--

DROP TABLE IF EXISTS `applicant_civilstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applicant_civilstatus` (
  `applicantID` int NOT NULL,
  `civilStatusID` int NOT NULL,
  PRIMARY KEY (`applicantID`,`civilStatusID`),
  KEY `civilStatusID_idx` (`civilStatusID`),
  CONSTRAINT `applicantID10` FOREIGN KEY (`applicantID`) REFERENCES `applicant` (`applicantID`),
  CONSTRAINT `civilStatusID` FOREIGN KEY (`civilStatusID`) REFERENCES `civilstatus` (`idcivilStatusID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicant_civilstatus`
--

LOCK TABLES `applicant_civilstatus` WRITE;
/*!40000 ALTER TABLE `applicant_civilstatus` DISABLE KEYS */;
/*!40000 ALTER TABLE `applicant_civilstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `applicant_country`
--

DROP TABLE IF EXISTS `applicant_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applicant_country` (
  `applicantID` int NOT NULL,
  `countryID` int NOT NULL,
  `city` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`applicantID`,`countryID`),
  KEY `countryID_idx` (`countryID`),
  CONSTRAINT `applicantID7` FOREIGN KEY (`applicantID`) REFERENCES `applicant` (`applicantID`),
  CONSTRAINT `countryID` FOREIGN KEY (`countryID`) REFERENCES `country` (`countryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicant_country`
--

LOCK TABLES `applicant_country` WRITE;
/*!40000 ALTER TABLE `applicant_country` DISABLE KEYS */;
/*!40000 ALTER TABLE `applicant_country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `applicant_language`
--

DROP TABLE IF EXISTS `applicant_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applicant_language` (
  `applicantID` int NOT NULL,
  `languageID` int NOT NULL,
  `languageLevel` int DEFAULT NULL,
  PRIMARY KEY (`applicantID`,`languageID`),
  KEY `languageID_idx` (`languageID`),
  CONSTRAINT `applicantID6` FOREIGN KEY (`applicantID`) REFERENCES `applicant` (`applicantID`),
  CONSTRAINT `languageID` FOREIGN KEY (`languageID`) REFERENCES `language1` (`languageID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicant_language`
--

LOCK TABLES `applicant_language` WRITE;
/*!40000 ALTER TABLE `applicant_language` DISABLE KEYS */;
/*!40000 ALTER TABLE `applicant_language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `applicant_nationality`
--

DROP TABLE IF EXISTS `applicant_nationality`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applicant_nationality` (
  `applicantID` int NOT NULL,
  `nationalityID` int NOT NULL,
  PRIMARY KEY (`applicantID`,`nationalityID`),
  KEY `nationalityID_idx` (`nationalityID`),
  CONSTRAINT `applicantID9` FOREIGN KEY (`applicantID`) REFERENCES `applicant` (`applicantID`),
  CONSTRAINT `nationalityID` FOREIGN KEY (`nationalityID`) REFERENCES `nationality` (`nationalityID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicant_nationality`
--

LOCK TABLES `applicant_nationality` WRITE;
/*!40000 ALTER TABLE `applicant_nationality` DISABLE KEYS */;
/*!40000 ALTER TABLE `applicant_nationality` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `applicant_skill`
--

DROP TABLE IF EXISTS `applicant_skill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applicant_skill` (
  `applicantID` int NOT NULL,
  `skillID` int NOT NULL,
  `skillLevel` int DEFAULT NULL,
  PRIMARY KEY (`applicantID`,`skillID`),
  KEY `skillID_idx` (`skillID`),
  CONSTRAINT `applicantID8` FOREIGN KEY (`applicantID`) REFERENCES `applicant` (`applicantID`),
  CONSTRAINT `skillID` FOREIGN KEY (`skillID`) REFERENCES `skill` (`skillID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicant_skill`
--

LOCK TABLES `applicant_skill` WRITE;
/*!40000 ALTER TABLE `applicant_skill` DISABLE KEYS */;
/*!40000 ALTER TABLE `applicant_skill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `applicant_socialmedia`
--

DROP TABLE IF EXISTS `applicant_socialmedia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applicant_socialmedia` (
  `socialMediaID` int NOT NULL,
  `applicantID` int NOT NULL,
  `link` varchar(250) NOT NULL,
  PRIMARY KEY (`socialMediaID`,`applicantID`,`link`),
  KEY `applicantID2_idx` (`applicantID`),
  CONSTRAINT `applicantID4` FOREIGN KEY (`applicantID`) REFERENCES `applicant` (`applicantID`),
  CONSTRAINT `socialMediaID` FOREIGN KEY (`socialMediaID`) REFERENCES `socialmedia` (`socialMediaID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicant_socialmedia`
--

LOCK TABLES `applicant_socialmedia` WRITE;
/*!40000 ALTER TABLE `applicant_socialmedia` DISABLE KEYS */;
/*!40000 ALTER TABLE `applicant_socialmedia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `applicant_vacancy`
--

DROP TABLE IF EXISTS `applicant_vacancy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applicant_vacancy` (
  `applicantID` int NOT NULL,
  `vacancyID` int NOT NULL,
  PRIMARY KEY (`applicantID`,`vacancyID`),
  KEY `applicantID_5_idx` (`applicantID`),
  KEY `vacancyID_idx` (`vacancyID`),
  CONSTRAINT `applicantID5` FOREIGN KEY (`applicantID`) REFERENCES `applicant` (`applicantID`),
  CONSTRAINT `vacancyID` FOREIGN KEY (`vacancyID`) REFERENCES `vacancy` (`vacancyID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicant_vacancy`
--

LOCK TABLES `applicant_vacancy` WRITE;
/*!40000 ALTER TABLE `applicant_vacancy` DISABLE KEYS */;
/*!40000 ALTER TABLE `applicant_vacancy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `civilstatus`
--

DROP TABLE IF EXISTS `civilstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `civilstatus` (
  `idcivilStatusID` int NOT NULL,
  `civiStatusDesc` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idcivilStatusID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `civilstatus`
--

LOCK TABLES `civilstatus` WRITE;
/*!40000 ALTER TABLE `civilstatus` DISABLE KEYS */;
INSERT INTO `civilstatus` VALUES (1,'Single'),(2,'Married'),(3,'Prefer Not to Disclose');
/*!40000 ALTER TABLE `civilstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contactinfo`
--

DROP TABLE IF EXISTS `contactinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contactinfo` (
  `applicantID` int NOT NULL,
  `phoneNumber` bigint DEFAULT NULL,
  `address1` varchar(60) DEFAULT NULL,
  `address2` varchar(60) DEFAULT NULL,
  `postCode` int DEFAULT NULL,
  PRIMARY KEY (`applicantID`),
  CONSTRAINT `contactinfo_ibfk_1` FOREIGN KEY (`applicantID`) REFERENCES `applicant` (`applicantID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contactinfo`
--

LOCK TABLES `contactinfo` WRITE;
/*!40000 ALTER TABLE `contactinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `contactinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `country` (
  `countryID` int NOT NULL,
  `country` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`countryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` VALUES (1,'Afghanistan'),(2,'Albania'),(3,'Algeria'),(4,'American Samoa'),(5,'Andorra'),(6,'Angola'),(7,'Argentina'),(8,'Armenia'),(9,'Australia'),(10,'Austria'),(11,'Azerbaijan'),(12,'Bahamas'),(13,'Bahrain'),(14,'Bangladesh'),(15,'Barbados'),(16,'Belarus'),(17,'Belgium'),(18,'Belize'),(19,'Benin'),(20,'Bermuda'),(21,'Bhutan'),(22,'Bolivia'),(23,'Bosnia And Herzegovina'),(24,'Botswana'),(25,'Brazil'),(26,'Bulgaria'),(27,'Burkina Faso'),(28,'Burundi'),(29,'Cambodia'),(30,'Cameroon'),(31,'Canada'),(32,'Cape Verde Islands'),(33,'Chad'),(34,'Chile'),(35,'China'),(36,'Colombia'),(37,'Congo'),(38,'Costa Rica'),(39,'Croatia'),(40,'Cuba'),(41,'Cyprus'),(42,'Czech Republic'),(43,'Denmark'),(44,'Djibouti'),(45,'Dominica'),(46,'Dominican Republic'),(47,'Ecuador'),(48,'Egypt'),(49,'El Salvador'),(50,'Eritrea'),(51,'Estonia'),(52,'Ethiopia'),(53,'Fiji'),(54,'Finland'),(55,'France'),(56,'French Polynesia'),(57,'Gabon'),(58,'Gambia'),(59,'Georgia'),(60,'Germany'),(61,'Ghana'),(62,'Greece'),(63,'Grenada'),(64,'Guatemala'),(65,'Guinea'),(66,'Guyana'),(67,'Haiti'),(68,'Honduras'),(69,'Hungary'),(70,'Iceland'),(71,'India'),(72,'Indonesia'),(73,'Iran'),(74,'Iraq'),(75,'Ireland'),(76,'Israel'),(77,'Italy'),(78,'Jamaica'),(79,'Japan'),(80,'Jordan'),(81,'Kazakhstan'),(82,'Kenya'),(83,'Korea'),(84,'North Korea'),(85,'Kuwait'),(86,'Latvia'),(87,'Lebanon'),(88,'Liberia'),(89,'Libya'),(90,'Lithuania'),(91,'Luxembourg'),(92,'Madagascar'),(93,'Malawi'),(94,'Malaysia'),(95,'Maldives'),(96,'Mali'),(97,'Malta'),(98,'Mauritania'),(99,'Mauritius'),(100,'Mexico'),(101,'Monaco'),(102,'Mongolia'),(103,'Montenegro'),(104,'Morocco'),(105,'Mozambique'),(106,'Namibia'),(107,'Nepal'),(108,'Netherlands'),(109,'New Zealand'),(110,'Nicaragua'),(111,'Niger'),(112,'Nigeria'),(113,'Norway'),(114,'Oman'),(115,'Pakistan'),(116,'Panama'),(117,'Papua New Guinea'),(118,'Paraguay'),(119,'Peru'),(120,'Philippines'),(121,'Poland'),(122,'Portugal'),(123,'Qatar'),(124,'Romania'),(125,'Rwanda'),(126,'Saudi Arabia'),(127,'Senegal'),(128,'Serbia'),(129,'Sierra Leone'),(130,'Singapore'),(131,'Slovakia'),(132,'Slovenia'),(133,'Solomon Islands'),(134,'Somalia'),(135,'South Africa'),(136,'Spain'),(137,'Sri Lanka'),(138,'Sudan'),(139,'Suriname'),(140,'Swaziland'),(141,'Sweden'),(142,'Switzerland'),(143,'Taiwan'),(144,'Tajikistan'),(145,'Thailand'),(146,'Togo'),(147,'Trinidad And Tobago'),(148,'Tunisia'),(149,'Turkey'),(150,'Turkmenistan'),(151,'Tuvalu'),(152,'Uganda'),(153,'Ukraine'),(154,'United Arab Emirates'),(155,'United Kingdom'),(156,'United States'),(157,'Uruguay'),(158,'Uzbekistan'),(159,'Vanuatu'),(160,'Venezuela'),(161,'Vietnam'),(162,'Yemen'),(163,'Zambia');
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `education`
--

DROP TABLE IF EXISTS `education`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `education` (
  `applicantID` int NOT NULL,
  `academicLevelID` int NOT NULL,
  `academic_institution_name` varchar(120) DEFAULT NULL,
  `academic_strart_date` date DEFAULT NULL,
  `academic_finish_date` date DEFAULT NULL,
  `academic_description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`applicantID`),
  KEY `academicLevelID` (`academicLevelID`),
  CONSTRAINT `applicantID` FOREIGN KEY (`applicantID`) REFERENCES `applicant` (`applicantID`),
  CONSTRAINT `education_ibfk_1` FOREIGN KEY (`academicLevelID`) REFERENCES `academiclevel` (`academicLevelID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `education`
--

LOCK TABLES `education` WRITE;
/*!40000 ALTER TABLE `education` DISABLE KEYS */;
/*!40000 ALTER TABLE `education` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `experience`
--

DROP TABLE IF EXISTS `experience`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `experience` (
  `applicantID` int NOT NULL,
  `jobTitle` varchar(45) DEFAULT NULL,
  `jobStartDate` varchar(45) DEFAULT NULL,
  `jobEndDate` varchar(45) DEFAULT NULL,
  `companyName` varchar(45) NOT NULL,
  `shortJobDescription` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`applicantID`,`companyName`),
  CONSTRAINT `experience_ibfk_1` FOREIGN KEY (`applicantID`) REFERENCES `applicant` (`applicantID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `experience`
--

LOCK TABLES `experience` WRITE;
/*!40000 ALTER TABLE `experience` DISABLE KEYS */;
/*!40000 ALTER TABLE `experience` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game`
--

DROP TABLE IF EXISTS `game`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game` (
  `applicantID` int NOT NULL,
  `vacancyID` int NOT NULL,
  `game_score` int DEFAULT NULL,
  PRIMARY KEY (`applicantID`,`vacancyID`),
  KEY `vacancyID_idx` (`vacancyID`),
  KEY `vacancyID2_idx` (`vacancyID`),
  CONSTRAINT `applicantID2` FOREIGN KEY (`applicantID`) REFERENCES `applicant` (`applicantID`),
  CONSTRAINT `vacancyID2` FOREIGN KEY (`vacancyID`) REFERENCES `vacancy` (`vacancyID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game`
--

LOCK TABLES `game` WRITE;
/*!40000 ALTER TABLE `game` DISABLE KEYS */;
/*!40000 ALTER TABLE `game` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language1`
--

DROP TABLE IF EXISTS `language1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `language1` (
  `languageID` int NOT NULL,
  `languageName` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`languageID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language1`
--

LOCK TABLES `language1` WRITE;
/*!40000 ALTER TABLE `language1` DISABLE KEYS */;
INSERT INTO `language1` VALUES (1,'Arab'),(2,'Chinese'),(3,'English'),(4,'French'),(5,'Indian'),(6,'Japanese'),(7,'Korean'),(8,'Portuguese'),(9,'Russian'),(10,'Spanish');
/*!40000 ALTER TABLE `language1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nationality`
--

DROP TABLE IF EXISTS `nationality`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nationality` (
  `nationalityID` int NOT NULL,
  `countryName` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`nationalityID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nationality`
--

LOCK TABLES `nationality` WRITE;
/*!40000 ALTER TABLE `nationality` DISABLE KEYS */;
INSERT INTO `nationality` VALUES (1,'Afghan'),(2,'Albanian'),(3,'Algerian'),(4,'American'),(5,'Andorran'),(6,'Angolan'),(7,'Argentinian'),(8,'Armenian'),(9,'Australian'),(10,'Austrian'),(11,'Azerbaijani'),(12,'Bahamian'),(13,'Bahraini'),(14,'Bangladeshi'),(15,'Barbadian'),(16,'Belarusian'),(17,'Belgian'),(18,'Belizean'),(19,'Beninese'),(20,'Bermudian'),(21,'Bhutanese'),(22,'Bolivian'),(23,'Bosnian'),(24,'Botswanan'),(25,'Brazilian'),(26,'British'),(27,'Bulgarian'),(28,'Burkinese'),(29,'Burundian'),(30,'Cambodian'),(31,'Cameroonian'),(32,'Canadian'),(33,'Cape Verdean'),(34,'Chadian'),(35,'Chilean'),(36,'Chinese'),(37,'Colombian'),(38,'Congolese'),(39,'Costa Rican'),(40,'Croat'),(41,'Cuban'),(42,'Cypriot'),(43,'Czech'),(44,'Danish'),(45,'Djiboutian'),(46,'Dominican'),(47,'Dutch'),(48,'Ecuadorean'),(49,'Egyptian'),(50,'Emirati'),(51,'Eritrean'),(52,'Estonian'),(53,'Ethiopian'),(54,'Fijian'),(55,'Finnish'),(56,'French'),(57,'Gabonese'),(58,'Gambian'),(59,'Georgian'),(60,'German'),(61,'Ghanaian'),(62,'Greek'),(63,'Grenadian'),(64,'Guatemalan'),(65,'Guinean'),(66,'Guinean'),(67,'Guyanese'),(68,'Haitian'),(69,'Honduran'),(70,'Hungarian'),(71,'Icelandic'),(72,'Indian'),(73,'Indonesian'),(74,'Iranian'),(75,'Iraqi'),(76,'Ireland'),(77,'Israeli'),(78,'Italian'),(79,'Jamaican'),(80,'Japanese'),(81,'Jordanian'),(82,'Kazakh'),(83,'Kenyan'),(84,'Kuwaiti'),(85,'Latvian'),(86,'Lebanese'),(87,'Liberian'),(88,'Libyan'),(89,'Lithuanian'),(90,'Luxembourg'),(91,'Madagascan'),(92,'Malawian'),(93,'Malaysian'),(94,'Maldivian'),(95,'Malian'),(96,'Maltese'),(97,'Mauritanian'),(98,'Mauritian'),(99,'Mexican'),(100,'Monacan'),(101,'Mongolian'),(102,'Montenegrin'),(103,'Moroccan'),(104,'Mozambican'),(105,'Namibian'),(106,'Nepalese'),(107,'New Zealand'),(108,'Nicaraguan'),(109,'Nigerian'),(110,'Nigerien'),(111,'North Korean'),(112,'Norwegian'),(113,'Omani'),(114,'Pakistani'),(115,'Panamanian'),(116,'Paraguayan'),(117,'Peruvian'),(118,'Philippine'),(119,'Polish'),(120,'Polynesian'),(121,'Portuguese'),(122,'Qatari'),(123,'Romanian'),(124,'Rwandan'),(125,'Salvadorean'),(126,'Samoan'),(127,'Saudi Arabian'),(128,'Senegalese'),(129,'Serb or Serbian'),(130,'Sierra Leonian'),(131,'Singaporean'),(132,'Slomoni'),(133,'Slovak'),(134,'Slovenian'),(135,'Somali'),(136,'South African'),(137,'South Korean'),(138,'Spanish'),(139,'Sri Lankan'),(140,'Sudanese'),(141,'Surinamese'),(142,'Swazi'),(143,'Swedish'),(144,'Swiss'),(145,'Taiwanese'),(146,'Tajik'),(147,'Thai'),(148,'Togolese'),(149,'Trinidadian'),(150,'Tunisian'),(151,'Turkish'),(152,'Turkoman'),(153,'Tuvaluan'),(154,'Ugandan'),(155,'Ukrainian'),(156,'Uruguayan'),(157,'Uzbek'),(158,'Vanuatuan'),(159,'Venezuelan'),(160,'Vietnamese'),(161,'Yemeni'),(162,'Zambian');
/*!40000 ALTER TABLE `nationality` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `skill`
--

DROP TABLE IF EXISTS `skill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `skill` (
  `skillID` int NOT NULL,
  `skillName` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`skillID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `skill`
--

LOCK TABLES `skill` WRITE;
/*!40000 ALTER TABLE `skill` DISABLE KEYS */;
INSERT INTO `skill` VALUES (1,'Python'),(2,'Javascript'),(3,'Java'),(4,'C#'),(5,'PHP'),(6,'C++/C'),(7,'R'),(8,'Objective-C'),(9,'Swift'),(10,'Matlab');
/*!40000 ALTER TABLE `skill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `socialmedia`
--

DROP TABLE IF EXISTS `socialmedia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `socialmedia` (
  `socialMediaID` int NOT NULL,
  `socialMediaName` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`socialMediaID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `socialmedia`
--

LOCK TABLES `socialmedia` WRITE;
/*!40000 ALTER TABLE `socialmedia` DISABLE KEYS */;
INSERT INTO `socialmedia` VALUES (1,'Skype'),(2,'LinkedIn'),(3,'Facebook'),(4,'Instagram'),(5,'Twitter'),(6,'YouTube');
/*!40000 ALTER TABLE `socialmedia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vacancy`
--

DROP TABLE IF EXISTS `vacancy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vacancy` (
  `vacancyID` int NOT NULL,
  `vacancyDesc` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`vacancyID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vacancy`
--

LOCK TABLES `vacancy` WRITE;
/*!40000 ALTER TABLE `vacancy` DISABLE KEYS */;
INSERT INTO `vacancy` VALUES (1,'QA Automation'),(2,'Data Engineer'),(3,'.Net Developer'),(4,'Data Scientist'),(5,'Java Developer'),(6,'FrontEnd Developer');
/*!40000 ALTER TABLE `vacancy` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-15  1:04:23
